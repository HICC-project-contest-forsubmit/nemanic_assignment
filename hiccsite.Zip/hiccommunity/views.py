from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Post, Comment
from django.views.decorators.csrf import csrf_exempt
import json


# 게시글 전체 조회
def get_all_posts(request):
    if request.method == "GET":
        posts = Post.objects.all().values('pid', 'title', 'content', 'create_date')
        return JsonResponse({"posts": list(posts)}, status=200)


# 특정 게시글 조회
def get_post_by_id(request, pid):
    if request.method == "GET":
        post = get_object_or_404(Post, pid=pid)
        return JsonResponse({
            "pid": post.pid,
            "title": post.title,
            "content": post.content,
            "create_date": post.create_date.strftime("%Y-%m-%d"),
        }, status=200)


# 게시글 작성
@csrf_exempt
def create_post(request):
    if request.method == "POST":
        data = json.loads(request.body)
        post = Post.objects.create(title=data['title'], content=data['content'])
        return JsonResponse({
            "pid": post.pid,
            "title": post.title,
            "content": post.content,
            "create_date": post.create_date.strftime("%Y-%m-%d"),
        }, status=201)

def get_comments(request, pid):
        if request.method == "GET":
            # 특정 게시글 가져오기
            post = get_object_or_404(Post, pid=pid)

            # 해당 게시글의 댓글 가져오기
            comments = post.comments.all().values('cid', 'content', 'create_date', 'post_id')

            # 응답 데이터 생성
            return JsonResponse({"comments": list(comments)}, status=200)


from django.shortcuts import render

# Create your views here.
