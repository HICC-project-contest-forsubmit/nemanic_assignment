from django.urls import path
from . import views

urlpatterns = [
    path('posts', views.get_all_posts, name='get_all_posts'),
    path('posts/new', views.create_post, name='create_post'),
    path('posts/<int:pid>', views.get_post_by_id, name='get_post_by_id'),
    path('posts/<int:pid>/comment', views.get_comments, name='get_comments'),  # 댓글 조회
]