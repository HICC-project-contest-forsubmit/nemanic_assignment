from django.db import models

class Post(models.Model):
    pid = models.AutoField(primary_key=True)  # 자동 생성 ID
    title = models.CharField(max_length=30)  # 제목 (최대 30자)
    content = models.TextField()  # 내용 (제한 없음)
    create_date = models.DateTimeField(auto_now_add=True)  # 작성 시간

    def __str__(self):
        return self.title


class Comment(models.Model):
    cid = models.AutoField(primary_key=True)  # 자동 생성 ID
    content = models.CharField(max_length=200)  # 댓글 내용 (최대 200자)
    create_date = models.DateTimeField(auto_now_add=True)  # 작성 시간
    post = models.ForeignKey(Post, related_name='comments', on_delete=models.CASCADE)  # 게시글과 연결

    def __str__(self):
        return f"{self.post.title} - {self.content[:20]}"