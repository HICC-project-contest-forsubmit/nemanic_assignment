from django.db import models

class Post(models.Model):
    title = models.CharField(max_length=30)  # 게시글 제목
    content = models.TextField()  # 게시글 내용
    create_date = models.DateTimeField(auto_now_add=True)  # 작성 시간

    def __str__(self):
        return self.title

class Comment(models.Model):
    content = models.CharField(max_length=200)  # 댓글 내용
    create_date = models.DateTimeField(auto_now_add=True)  # 댓글 작성 시간
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name="comments")  # 게시글 참조

    def __str__(self):
        return self.content