from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Post, Comment


# 기본 경로 뷰
def root_view(request):
    return JsonResponse({
        "message": "Welcome to the API root!",
        "endpoints": {
            "GET /api/posts": "Fetch all posts",
            "POST /api/posts": "Create a new post",
            "GET /api/posts/<pid>": "Fetch a single post by id",
            "GET /api/posts/<pid>/comment": "Fetch comments for a specific post",
            "POST /api/posts/<pid>/comment": "Add a comment to a specific post"
        }
    }, status=200)


# 게시글 전체 조회
def get_all_posts(request):
    if request.method == "GET":
        posts = Post.objects.all().values('id', 'title', 'content', 'create_date')
        return JsonResponse({"posts": list(posts)}, status=200)


# 특정 게시글 조회
def get_post_by_id(request, pid):
    if request.method == "GET":
        post = get_object_or_404(Post, id=pid)
        response_data = {
            "pid": post.id,
            "title": post.title,
            "content": post.content,
            "create_date": post.create_date.strftime("%Y-%m-%d")
        }
        return JsonResponse(response_data, status=200)


# 게시글 작성
@csrf_exempt
def create_post(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            title = data.get("post_title")
            content = data.get("post_content")

            if not title or not content:
                return JsonResponse({"error": "제목과 내용을 모두 입력해주세요."}, status=400)

            if len(title) > 30:
                return JsonResponse({"error": "제목은 30자를 초과할 수 없습니다."}, status=400)

            post = Post.objects.create(title=title, content=content)
            response_data = {
                "pid": post.id,
                "title": post.title,
                "content": post.content,
                "create_date": post.create_date.strftime("%Y-%m-%d")
            }
            return JsonResponse(response_data, status=200)
        except json.JSONDecodeError:
            return JsonResponse({"error": "잘못된 JSON 데이터입니다."}, status=400)
    return JsonResponse({"error": "잘못된 요청 방식입니다."}, status=405)


# 특정 게시글의 댓글 조회
def get_comments(request, pid):
    if request.method == "GET":
        post = get_object_or_404(Post, id=pid)
        comments = post.comments.all().values('id', 'content', 'create_date', 'post_id')
        return JsonResponse({"comments": list(comments)}, status=200)


# 댓글 작성
@csrf_exempt
def create_comment(request, pid):
    if request.method == "POST":
        try:
            post = get_object_or_404(Post, id=pid)
            data = json.loads(request.body)
            content = data.get("comment_content")

            if not content:
                return JsonResponse({"error": "댓글 내용을 입력해주세요."}, status=400)

            if len(content) > 200:
                return JsonResponse({"error": "댓글은 200자를 초과할 수 없습니다."}, status=400)

            comment = Comment.objects.create(content=content, post=post)
            response_data = {
                "cid": comment.id,
                "content": comment.content,
                "create_date": comment.create_date.strftime("%Y-%m-%dT%H:%M"),
                "post": comment.post.id
            }
            return JsonResponse(response_data, status=200)
        except json.JSONDecodeError:
            return JsonResponse({"error": "잘못된 JSON 데이터입니다."}, status=400)
    return JsonResponse({"error": "잘못된 요청 방식입니다."}, status=405)
