from django.urls import path
from .views import root_view, get_all_posts, get_post_by_id, create_post, get_comments, create_comment

urlpatterns = [
    path('', root_view, name='root_view'),  # API 기본 경로
    path('posts', get_all_posts, name='get_all_posts'),  # 게시글 전체 조회
    path('posts/new', create_post, name='create_post'),  # 새 게시글 작성
    path('posts/<int:pid>', get_post_by_id, name='get_post_by_id'),  # 특정 게시글 조회
    path('posts/<int:pid>/comment', get_comments, name='get_comments'),  # 특정 게시글의 댓글 조회
    path('posts/<int:pid>/comment/new', create_comment, name='create_comment'),  # 새 댓글 작성
]