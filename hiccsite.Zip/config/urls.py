from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('api.urls')),  # API URL 연결
    path('hiccommunity/', include('hiccommunity.urls')),  # hiccommunity URL 연결
]